<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Vive Bellisima</title>    
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css"
          href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/material-dashboard.css?v=2.1.1')); ?>" rel="stylesheet"/>
    
</head>
<body>
    <div class="container-fluid">
    	<?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Scripts -->
    
    <!--   Core JS Files   -->

</body>
</html>
<?php /**PATH C:\xampp\htdocs\vive-bellisima\resources\views/layouts/login.blade.php ENDPATH**/ ?>