<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header card-header-info">
					<h4 class="card-title ">Usuarios</h4>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table">
							<thead class=" text-primary">
								<th>
									Nombre
								</th>
								<th>
									<?php echo e($usuario->full_name); ?>

								</th>
							</thead>
							<tbody>
								<tr>
									<td>
										Folio
									</td>
									<td>
										<?php echo e($usuario->id); ?>

									</td>
								</tr>
								<tr>
									<td>
										Ciudad
									</td>
									<td>
										<?php echo e(ucwords($usuario->city)); ?>

									</td>
								</tr>
								<tr>
									<td>
										Estado
									</td>
									<td>
										<?php echo e(ucwords($usuario->state)); ?>

									</td>
								</tr>
								<tr>
									<td>
										Domicilio
									</td>
									<td>
										<?php echo e(ucwords($usuario->address)); ?>

									</td>
								<tr>
									<td>
										CURP
									</td>
									<td>
										<?php echo e($usuario->curp); ?>

									</td>

								</tr>
								<tr>
									<td>
										Nivel
									</td>
									<td>
										<?php echo e($usuario->level); ?>

									</td>
								</tr>
								<tr>
									<td>
										Foto
									</td>
									<td>
										<img src="<?php echo e(asset('img/user.jpg')); ?>" alt=""/>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="row">
						<div class="col-md-2">
							<a href="javascript:history.back();"><button class="btn btn-info"><i class="material-icons">arrow_back</i> Atrás
							</button></a>
						</div>


					</div>
				</div>
			</div>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vive-bellisima\resources\views/users/show.blade.php ENDPATH**/ ?>